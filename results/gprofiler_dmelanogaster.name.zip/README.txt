
This is a collection of gmt files with the data underlying the g:GOSt enrichment service.
gmt files are plaintext tab-separated files that can be opened in text editors (notepad) or spreadsheet editors (Excel).

TRANSFAC (TF) and KEGG are omitted from this archive due to licensing issues.

Previous versions of this archive contained the file dmelanogaster.pathways.name.gmt. The equivalent file is dmelanogaster.GO:BP.name.gmt

                